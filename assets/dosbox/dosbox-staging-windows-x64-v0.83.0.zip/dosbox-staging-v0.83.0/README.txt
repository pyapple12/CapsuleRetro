Welcome to DOSBox Staging, a modern continuation of the DOSBox project that
focuses on ease of use, advanced features, and current development practices.

This package contains release v0.83.0 of the DOSBox Staging project.

DOSBox Staging is meant as a (mostly) drop-in replacement for older DOSBox
versions --- your existing configurations will continue to work, but you will
have access to many advanced features.

Run the MANUAL command from the DOS prompt to open the bundled offline copy of
the User Manual in your default browser, or the GUIDE command for the Getting
Started guide.

Check out our project website to learn more:
https://www.dosbox-staging.org/


You can report bugs and ask questions in our GitHub repository:
https://github.com/dosbox-staging/dosbox-staging

If you want to chat, you will find fellow users and developers in the
#dosbox-staging channel of Luxtorpeda project's Discord server:

https://discord.gg/WwAg3Xf


Have fun!

--The DOSBox Staging team
